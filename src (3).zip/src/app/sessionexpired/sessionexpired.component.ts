import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sessionexpired',
  templateUrl: './sessionexpired.component.html',
  styleUrls: ['./sessionexpired.component.css']
})
export class SessionexpiredComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
