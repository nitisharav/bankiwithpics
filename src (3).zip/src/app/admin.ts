export class Login {
        "userId":string;
        "password":string;
}

export class AccountHolderDetails {
    constructor(){}
    public firstName:       string;
    public accountNumber:   number;
    public refernceId:      number;
    public approvedByAdmin: string;
    public adminRemark:     string;
}
export class Forgotpassword {
     "userId": string;
     "password": string;
}

export class Forgotuserid {
    "accNumber":string;
}

export class UserRegister{
    constructor(){}
    "accNumber" : string;
    "loginPassword" : string;
    "transactionnPassword": string
}

export class AdminRegister{
    public adminuserid:string;
     public adminpassword:string;
     public adminname:string;
  }

export class OpenAccount{
    
  //  public title :string;
    public firstname :string;
  //  public middleName :string;
    public lastname  :string;
    public mobileno :string;
    public email :string;
    public fathersname  :string;
   // public motherName  :string;
    public adharcard :string;
    public dob  :string;
   // public resAddress1 :string;
  //  public resAddress2 :string;
   // public resLandMark  :string;
    public presstate :string;
    public prescity :string;
    public preszipcode :string;
    public presaddressline1 :string;
    public presaddressline2 :string;
  //  public perLandMark :string;
  //  public presstate  :string;
  //  public prescity  :string;
  //  public perPincode  :string;
    public occupationtype :string;
    public sourceofincome :string;
    public grossannualincome :string;
    public annualSalary :string;
}

export class userDetails{
    
    public firstName :string;
  //  public middleName :string;
    public lastName  :string;
    public mobileNumber :string;
    public email :string;
    public aadharCard :string;
    public resAddress1 :string;
    public resAddress2 :string;
   // public resLandMark  :string;
    public resState :string;
    public resCity :string;
    public resPincode :string;
    public accountBalance : string;
    public occupation :string;

}

export class AddBeneficiary{
      uaccno: string;
      paccno: string;
      pname: string;
	//  nickName: string;
}

export class FundsDataClass{
    fromaccno:string;
    toaccno:string;
    fundmode:string;
    balance:number;
    tnpass :string;
}

export class TransactionHistory{
    frmdate:string;
    todate:string;
    accno:string;
}
