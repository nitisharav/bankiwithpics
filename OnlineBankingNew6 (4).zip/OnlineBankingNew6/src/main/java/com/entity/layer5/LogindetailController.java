package com.entity.layer5;


	import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RestController;

import com.entity.layer1.Logindetail;
import com.entity.layer1.Userdetail;
import com.entity.layer3.LoginForgotPasswordDataDto;
import com.entity.layer3.Logindatadto;

//import com.lti.exception.ServiceException;

import com.entity.layer4.LoginService;
import com.entity.layer6.ForgetPasswordStatus;
import com.entity.layer6.Status;
import com.entity.layer6.Status.StatusType;
import com.entity.layer6.UserLoginStatus;
import com.entity.layer6.UserRegisterStatus;



	@CrossOrigin(origins="http://localhost:4200")
	@RestController
	public class LogindetailController {
		
		@Autowired
		private LoginService service;
		
		@PostMapping(path="/userRegister")
		
		public Status registerUser(@RequestBody Logindatadto user) {
			try {
			String userId=service.registerUser(user);
			
			UserRegisterStatus registerStatus = new UserRegisterStatus();
			
			registerStatus.setUserId(userId);
			registerStatus.setStatus(StatusType.SUCCESS);
			registerStatus.setMessage("User Registered");
			
			return registerStatus;
			}
			catch(Exception e) {
				
			Status registerStatus = new Status();
			registerStatus.setStatus(StatusType.FAILURE);
			registerStatus.setMessage("try again");
				
			return registerStatus;
			}
		}
		
		@PostMapping(path="/userLogin")
		private Status loginUser(@RequestBody LoginForgotPasswordDataDto loginuser) {
			
			Userdetail acc;
			
		try {
			Logindetail user = service.loginUser(loginuser.getUserId(),loginuser.getPassword());
			acc=user.getUserdetail2();
			System.out.println("hello");
			UserLoginStatus loginStatus = new UserLoginStatus();
			
			loginStatus.setStatus(StatusType.SUCCESS);
			loginStatus.setInvalidLogins(user.getNumberofinvalidattempts());
			loginStatus.setAccountNumber(acc.getAccountno());
			loginStatus.setMessage("Login Successful");
			
			return loginStatus;
		}
		catch(Exception e) {
			
			UserLoginStatus loginStatus = new UserLoginStatus();
			if(e.getMessage().equals("User Doesn't Exist")) {
				
				loginStatus.setStatus(StatusType.FAILURE);
				loginStatus.setMessage(e.getMessage());
					
				return loginStatus;
			}
			else {
				
				loginStatus.setInvalidLogins(service.getInvalidAttempts(loginuser.getUserId()));
				loginStatus.setStatus(StatusType.FAILURE);
				loginStatus.setMessage(e.getMessage());
					
				return loginStatus;
			}
		}
		}
		@PostMapping(path="/forgetPassword")
		private Status forgetPassword(@RequestBody LoginForgotPasswordDataDto forgetPassword) {
			ForgetPasswordStatus forgetPasswordStatus = new ForgetPasswordStatus();
			try {
			String newPassword= service.resetPassword(forgetPassword.getUserId(),forgetPassword.getPassword());
			
			forgetPasswordStatus.setPassword(newPassword);
			forgetPasswordStatus.setStatus(StatusType.SUCCESS);
			forgetPasswordStatus.setMessage("Password Change Successful");
			
			return forgetPasswordStatus;
			}
			catch(Exception e) {
				Status status= new Status();
				
				status.setStatus(StatusType.FAILURE);
				status.setMessage(e.getMessage());
				
				return status;
			}
		}
		
		@PostMapping(path="/getUserId")
		private Status getUserID(@RequestBody Logindatadto getUserId) {
			try {
			Status status = new Status();
			
			String userId=service.getUserId(getUserId.getAccNumber());
			
			status.setStatus(StatusType.SUCCESS);
			status.setMessage("Your User Id is "+userId);
			return status;
			}
			catch(Exception e) {
				Status userIdStatus = new Status();
				
				userIdStatus.setStatus(StatusType.FAILURE);
				userIdStatus.setMessage(e.getMessage());
				
				return userIdStatus;
			}
		}

		@PostMapping(path="/forgetTransactionPassword")
		private Status forgetTransactionPassword(@RequestBody LoginForgotPasswordDataDto forgetPassword) {
			ForgetPasswordStatus forgetPasswordStatus = new ForgetPasswordStatus();
			try {
			String newPassword= service.resetTransactionPassword(forgetPassword.getUserId(),forgetPassword.getPassword());
			
			forgetPasswordStatus.setPassword(newPassword);
			forgetPasswordStatus.setStatus(StatusType.SUCCESS);
			forgetPasswordStatus.setMessage("Password Change Successful");
			
			return forgetPasswordStatus;
			}
			catch(Exception e) {
				Status status= new Status();

				status.setStatus(StatusType.FAILURE);
				status.setMessage(e.getMessage());
				
				return status;
			}
		}

	}



