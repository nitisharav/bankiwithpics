package com.entity.layer6;

public class ForgetPasswordStatus extends Status {
	private String password;

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
