package com.entity.layer4;


	import java.time.LocalDateTime;
	import java.time.format.DateTimeFormatter;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.dao.EmptyResultDataAccessException;
	import org.springframework.stereotype.Service;

import com.entity.layer1.Logindetail;
import com.entity.layer1.Userdetail;
import com.entity.layer2.LoginDetailRepository;
import com.entity.layer3.Logindatadto;

	
	@Service
	public class LoginserviceImpl implements LoginService {
		@Autowired	
		LoginDetailRepository log;
		
		public String registerUser(Logindatadto user) throws Exception {
			String userid="60001";
			Logindetail userlogin =new Logindetail();
			Userdetail usd;
			if(log.isAccountRegistered(user.getAccNumber())) {
				throw new Exception("Already Registered User");
		//	System.out.println("Already Registered User");
			}
			
		usd = log.findbyId(user.getAccNumber());
		
		if(usd==null) {
		//	System.out.println("Account Not Found");
			throw new Exception("Account Not Found");
		}
		else
		userlogin.setUserdetail2(usd);
		userlogin.setLoginPassword(user.getLoginPassword());
		userlogin.setTransactionPassword(user.getTransactionnPassword());
		if(log.isUserPresent()==false) {
			userlogin.setUserid(userid); 
			System.out.println("Login table is empty");
		}
		else {
			System.out.println("Login table is not empty");
			System.out.println(log.getUserId()+"userid of last account");
			int num = Integer.parseInt(log.getUserId());
			num++;
			userlogin.setUserid(Integer.toString(num));
		}
		
		log.save(userlogin);
		
		return userlogin.getUserid();
	}

		public Logindetail loginUser(String userId, String password) throws Exception {
		
	/*	if(!log.isUserValid(userId))
		{	
			System.out.println("akm");
			System.out.println("User Doesn't Exist");
		}*/
		//else {
			System.out.println("shub");
			int attempts = log.getNoOfInvalidAttempts(userId);
			
			if(attempts>3){
			
				throw new Exception("account blocked");				
				}
			/*else*/ if(!log.validUserIdPassword(userId, password)) {
				log.setNoOfInvalidAttempts(userId, attempts+1);
			//	System.out.println("Invalid Credentials");
				throw new Exception("Invalid Credentials");	
			}
			log.setNoOfInvalidAttempts(userId, 0);
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
			LocalDateTime now = LocalDateTime.now();
			
			log.savelastLogin(userId,dtf.format(now));
			Logindetail LD = log.findUserById(userId);
			return LD;
		}
		
		
		


	public int getInvalidAttempts(String userId) {
		System.out.println("akm");
		return log.getNoOfInvalidAttempts(userId);
	}

	@Override
	public String resetPassword(String userId, String updatedPassword) throws Exception {
		// TODO Auto-generated method stub
		if(!log.isUserValid(userId))
		{	
			throw new Exception("User Doesn't Exist");
		}
		log.setNoOfInvalidAttempts(userId, 0);
		log.resetPassword(userId,updatedPassword);
		return updatedPassword;
	}

	@Override
	public String getUserId(String accNumber) {
		// TODO Auto-generated method stub
		try {
		return log.getUserByAccNumber(accNumber);
		}
		catch(Exception e) {
			System.out.println("Please Register First");
		}
		return accNumber;
	}
	@Override
	public String resetTransactionPassword(String userId, String updatedPassword) {
		// TODO Auto-generated method stub
		if(!log.isUserValid(userId))
		{	
			System.out.println("User Doesn't Exist");
		}
		log.resetTransactionPassword(userId,updatedPassword);
		return updatedPassword;
	}




	}




